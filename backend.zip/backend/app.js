// var createError = require('http-errors');
// var express = require('express');
// var path = require('path');
// var cookieParser = require('cookie-parser');
// var logger = require('morgan');

// var indexRouter = require('./routes/index');
// var usersRouter = require('./routes/users');

// var app = express();

// // view engine setup
// app.set('views', path.join(__dirname, 'views'));
// app.set('view engine', 'jade');

// app.use(logger('dev'));
// app.use(express.json());
// app.use(express.urlencoded({ extended: false }));
// app.use(cookieParser());
// app.use(express.static(path.join(__dirname, 'public')));

// app.use('/', indexRouter);
// app.use('/users', usersRouter);

// // catch 404 and forward to error handler
// app.use(function(req, res, next) {
//   next(createError(404));
// });

// // error handler
// app.use(function(err, req, res, next) {
//   // set locals, only providing error in development
//   res.locals.message = err.message;
//   res.locals.error = req.app.get('env') === 'development' ? err : {};

//   // render the error page
//   res.status(err.status || 500);
//   res.render('error');
// });



// app.js
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mongoose = require('./db'); // Import the MongoDB connection
const Book = require('./book.mode');
const cors = require('cors')
app.use(cors())
app.use(bodyParser.json());

// CRUD routes
app.get('/books', async (req, res) => {
  try {
    const books = await Book.find();
    res.json(books);
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.get('/books/:isbn', async (req, res) => {
  const isbn = req.params.isbn;
  try {
    const book = await Book.findOne({ isbn });
    if (!book) {
      res.status(404).json({ message: 'Book not found' });
      return;
    }
    res.json(book);
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/books', async (req, res) => {
  const newBook = req.body;
  console.log(newBook,"books");
  try {
    const createdBook = await Book.create(newBook);
    res.status(201).json(createdBook);
  } catch (error) {
    res.status(400).json({ message: 'Invalid request body',error:error });
  }
});

app.put('/books/:isbn', async (req, res) => {
  const isbn = req.params.isbn;
  const updatedBook = req.body;
  try {
    const book = await Book.findOneAndUpdate({ isbn }, updatedBook, { new: true });
    if (!book) {
      res.status(404).json({ message: 'Book not found' });
      return;
    }
    res.json(book);
  } catch (error) {
    res.status(400).json({ message: 'Invalid request body' });
  }
});

app.delete('/books/:isbn', async (req, res) => {
  const isbn = req.params.isbn;
  try {
    const result = await Book.deleteOne({ isbn });
    if (result.deletedCount === 0) {
      res.status(404).json({ message: 'Book not found' });
      return;
    }
    res.json({ message: 'Book deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});

module.exports = app; // Export for testing purposes



