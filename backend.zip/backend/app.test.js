// app.test.js
const request = require('supertest');
const app = require('./app');
const mongoose = require('mongoose');

beforeAll(async () => {
  await mongoose.connect('mongodb://localhost:27017/bookstore-test', { useNewUrlParser: true, useUnifiedTopology: true });
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('Book API Tests', () => {
  // Add your test cases here
});

// app.test.js
describe('Book API Tests', () => {
    test('GET /books should return a list of books', async () => {
      const response = await request(app).get('/books');
      expect(response.status).toBe(200);
      expect(response.body).toHaveLength(0); // Assuming there are no books initially
    });
  
    test('POST /books should create a new book', async () => {
      const newBook = {
        title: 'Test Book',
        author: 'Test Author',
        description: 'Test Description',
        publicationYear: 2022,
        isbn: '1234567890',
      };
  
      const response = await request(app).post('/books').send(newBook);
      expect(response.status).toBe(201);
      expect(response.body.title).toBe(newBook.title);
    });
  
    // Add more test cases for other routes
  });
  
